# Security Checklist
- API key is environment/Secret Manager only.
- Never commit secrets.
- Never ship provider credentials in Android.
- HTTPS only.
- Validate all client inputs.
- Rate limit public API.
- Avoid storing precise location unless strictly necessary.
- Avoid precise location in logs.
- Verify public-data license and commercial-use terms before launch.
