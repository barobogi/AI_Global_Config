# API Contract

POST `/api/v1/seats/nearby`

Request:
```json
{"lat":37.2636,"lng":127.0286,"max_walk_minutes":15,"sort":"seats"}
```

Response:
```json
[
  {
    "library_name":"A도서관",
    "room_name":"3층 열람실",
    "remaining_seats":36,
    "total_seats":200,
    "walk_minutes":5,
    "updated_at":"2분 전"
  }
]
```

The response is a normalized internal contract. Provider-specific B551982 fields must be mapped only after official schema verification.
