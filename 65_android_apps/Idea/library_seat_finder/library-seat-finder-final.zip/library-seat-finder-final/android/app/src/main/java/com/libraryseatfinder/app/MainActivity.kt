package com.libraryseatfinder.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Column(Modifier.padding(20.dp)) {
                    Text("빈자리 있어요?", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("지금 갈 수 있는 도서관의 빈자리를 찾습니다.")
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {}) { Text("주변 빈자리 찾기") }
                    Spacer(Modifier.height(20.dp))
                    Text("A도서관 · 3층 열람실", style=MaterialTheme.typography.titleLarge)
                    Text("잔여 36석 / 총 200석 · 도보 5분 · 2분 전")
                    Spacer(Modifier.height(12.dp))
                    Text("B도서관 · 종합열람실", style=MaterialTheme.typography.titleLarge)
                    Text("잔여 11석 / 총 120석 · 도보 9분 · 1분 전")
                }
            }
        }
    }
}
