# 빈자리 있어요? — Final Release Candidate

V1 Lean 기획을 기반으로 한 최종 구현 베이스.
핵심은 주변 도서관/열람실의 잔여좌석을 빠르게 찾는 것.

## 실행
```bash
cd backend
pip install -r requirements.txt
uvicorn app:app --reload
```

실제 B551982 키는 `.env` 또는 배포 Secret에 넣는다.
공식 응답 스키마를 Phase 0에서 확인한 뒤 `worker/adapters/public_b551982.py`의 mapping을 확정한다.
