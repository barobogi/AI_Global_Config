from app import nearby, NearbyRequest

def test_zero_seats_are_excluded():
    assert all(x["remaining_seats"] > 0 for x in nearby(NearbyRequest(lat=37,lng=127)))
