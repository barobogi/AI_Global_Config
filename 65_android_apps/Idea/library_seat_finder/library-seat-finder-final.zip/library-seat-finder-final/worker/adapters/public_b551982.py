import os
import httpx

class B551982Provider:
    def __init__(self):
        self.key = os.getenv("B551982_API_KEY", "")
        self.endpoint = os.getenv("B551982_ENDPOINT", "https://apis.data.go.kr/B551982/plr_v2")

    async def fetch(self, params: dict):
        if not self.key:
            raise RuntimeError("B551982_API_KEY is not configured")
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(self.endpoint, params={**params, "serviceKey": self.key})
            r.raise_for_status()
            return r.json()

    def normalize(self, raw: dict) -> list[dict]:
        # Official response field mapping must be filled after Phase 0 schema verification.
        # Do not guess field names.
        raise NotImplementedError("Confirm official B551982 response schema first")
