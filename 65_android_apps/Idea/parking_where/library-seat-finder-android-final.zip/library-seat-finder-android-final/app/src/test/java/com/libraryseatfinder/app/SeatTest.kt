package com.libraryseatfinder.app
import org.junit.Assert.assertEquals
import org.junit.Test
class SeatTest { @Test fun remainingIsDisplayed(){ val s=Seat("A","R",12,100,5,"1분 전"); assertEquals(12,s.remaining) } }
