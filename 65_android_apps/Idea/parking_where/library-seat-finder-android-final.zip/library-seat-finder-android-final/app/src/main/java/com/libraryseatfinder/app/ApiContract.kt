package com.libraryseatfinder.app
object ApiContract { const val NEARBY="/api/v1/seats/nearby" }
