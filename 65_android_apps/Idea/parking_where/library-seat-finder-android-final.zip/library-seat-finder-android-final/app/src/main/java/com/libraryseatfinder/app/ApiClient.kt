package com.libraryseatfinder.app
import okhttp3.*
import java.io.IOException
class ApiClient(private val baseUrl:String="http://10.0.2.2:8000"){
 fun nearby(lat:Double,lng:Double,maxWalk:Int,sort:String,callback:(String?)->Unit){
  val body="""{"lat":$lat,"lng":$lng,"max_walk_minutes":$maxWalk,"sort":"$sort"}""".toRequestBody("application/json".toMediaType())
  val req=Request.Builder().url("$baseUrl/api/v1/seats/nearby").post(body).build()
  OkHttpClient().newCall(req).enqueue(object:Callback{
   override fun onFailure(call:Call,e:IOException){callback(null)}
   override fun onResponse(call:Call,r:Response){callback(r.body?.string())}
  })
 }
}
