package com.libraryseatfinder.app
import android.Manifest
import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity:Activity(){
 private val permissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{
  var sort by remember{mutableStateOf("seats")}
  var maxWalk by remember{mutableStateOf(15f)}
  var searched by remember{mutableStateOf(false)}
  MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("빈자리 있어요?")})}){p->
   Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("지금 갈 수 있는 빈자리",style=MaterialTheme.typography.headlineSmall)
    Button(onClick={permissions.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION));searched=true},Modifier.fillMaxWidth()){Text("내 위치로 찾기")}
    Text("최대 도보 ${maxWalk.toInt()}분")
    Slider(value=maxWalk,onValueChange={maxWalk=it},valueRange=5f..60f,steps=10)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     FilterChip(selected=sort=="seats",onClick={sort="seats"},label={Text("빈자리 많은 순")})
     FilterChip(selected=sort=="distance",onClick={sort="distance"},label={Text("가까운 순")})
    }
    if(searched){Text("주변 결과",style=MaterialTheme.typography.titleLarge)}
    listOf(Seat("A도서관","3층 열람실",36,200,5,"2분 전"),Seat("B도서관","종합열람실",11,120,9,"1분 전")).sortedWith(if(sort=="distance")compareBy{it.walkMinutes?:999}else compareByDescending{it.remaining}).let{
      LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(it){Result(it)}}
    }
   }
  }
 }}
}
@Composable fun Result(s:Seat){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
 Text(s.libraryName,style=MaterialTheme.typography.titleLarge);Text(s.roomName)
 Text("잔여 ${s.remaining}석 / 총 ${s.total}석",style=MaterialTheme.typography.headlineSmall)
 Text("도보 약 ${s.walkMinutes?:-1}분 · ${s.updatedAt?:"갱신정보 없음"}")
 Button(onClick={}){Text("길찾기")}
}}}
