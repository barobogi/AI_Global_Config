package com.libraryseatfinder.app
data class Seat(val libraryName:String,val roomName:String,val remaining:Int,val total:Int,val walkMinutes:Int?,val updatedAt:String?)
