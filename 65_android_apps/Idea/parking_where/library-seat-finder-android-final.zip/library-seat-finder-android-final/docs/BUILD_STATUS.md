# Build status
- Full Android Studio source tree: included.
- Location permission flow: included.
- Compose UI: included.
- Sort and walk-time controls: included.
- HTTP client: included.
- Unit test: included.
- Provider key: intentionally not included.
- B551982 official field mapping: intentionally not guessed; requires authenticated response verification.
