from fastapi import FastAPI
from pydantic import BaseModel
app=FastAPI()
class Q(BaseModel): lat:float; lng:float; max_walk_minutes:int=15; sort:str="seats"
DEMO=[{"library_name":"A도서관","room_name":"3층 열람실","remaining_seats":36,"total_seats":200,"walk_minutes":5,"updated_at":"2분 전"},
{"library_name":"B도서관","room_name":"종합열람실","remaining_seats":11,"total_seats":120,"walk_minutes":9,"updated_at":"1분 전"}]
@app.get("/health")
def health(): return {"status":"ok"}
@app.post("/api/v1/seats/nearby")
def nearby(q:Q):
 r=[x for x in DEMO if x["remaining_seats"]>0 and x["walk_minutes"]<=q.max_walk_minutes]
 r.sort(key=(lambda x:x["walk_minutes"]) if q.sort=="distance" else (lambda x:-x["remaining_seats"]))
 return r
