Backend reference contract is included separately in the production ZIP. Android expects POST /api/v1/seats/nearby.
