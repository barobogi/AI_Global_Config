plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.parkingwhere.app"; compileSdk = 37
    defaultConfig { applicationId = "com.parkingwhere.app"; minSdk = 26; targetSdk = 37; versionCode = 2; versionName = "2.0.0" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2026.08.00"))
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
}
