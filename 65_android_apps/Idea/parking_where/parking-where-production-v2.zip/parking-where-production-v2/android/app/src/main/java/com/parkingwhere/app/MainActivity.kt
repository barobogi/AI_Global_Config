package com.parkingwhere.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ParkingCard(
    val name: String, val price: Int, val success: Int, val confidence: Int, val walk: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ParkingWhereApp() }
    }
}

@Composable
fun ParkingWhereApp() {
    var destination by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("3시간") }
    val demo = listOf(
        ParkingCard("A 주차장", 6000, 92, 95, 5),
        ParkingCard("B 주차장", 4000, 84, 92, 9),
        ParkingCard("C 주차장", 3000, 58, 70, 4)
    )
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("주차 어디가?") }) }) { pad ->
            LazyColumn(modifier = Modifier.padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    OutlinedTextField(destination, { destination = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("어디로 가세요?") })
                }
                item {
                    OutlinedTextField(duration, { duration = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("주차시간") })
                }
                item {
                    Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                        Text("지금 추천받기")
                    }
                }
                items(demo.size) { i ->
                    val p = demo[i]
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleLarge)
                            Text("주차 성공 가능성 ${p.success}%")
                            Text("데이터 신뢰도 ${p.confidence}%")
                            Text("${p.price}원 · 도보 ${p.walk}분")
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {}) { Text("왜 추천?") }
                                Button(onClick = {}) { Text("길찾기") }
                            }
                        }
                    }
                }
            }
        }
    }
}
