# Data Ingestion Worker

공공데이터/제휴 API adapter를 연결하는 자리.

원칙:
1. 원본 응답을 무조건 신뢰하지 않는다.
2. 수집 시각과 원천을 저장한다.
3. 필드 검증/정규화 후 canonical parking model로 변환한다.
4. API key는 환경변수/secret manager에서 읽는다.
5. 장애 시 최근 정상 데이터와 freshness를 표시한다.

실제 한국교통안전공단 API의 필드/상업적 이용조건은 공식 명세 확인 후 adapter를 구현한다.
