# 주차 어디가? — Production V2

공공데이터 + 실시간/사용자 현장 데이터 + 데이터 신뢰도 + 주차 성공 가능성 기반의 주차 의사결정 서비스 스타터.

## 구성
- `android/`: Kotlin + Jetpack Compose 앱 골격
- `backend/`: FastAPI REST API, 추천/신뢰도/Plan B
- `worker/`: 공공데이터 수집 Worker 골격
- `infra/`: PostgreSQL + Redis Docker Compose
- `docs/`: 상용화 기획/아키텍처/API/보안
- `scripts/`: 개발/검증 스크립트

## 실행
1. `cp .env.example .env`
2. `docker compose -f infra/docker-compose.yml up -d`
3. `cd backend && python -m venv .venv`
4. 활성화 후 `pip install -r requirements.txt`
5. `uvicorn app.main:app --reload --port 8000`
6. `GET /health`, `GET /api/v1/parking/recommendations`

실제 공공 API/지도/로그인/결제 키는 `.env`에 넣고 Android APK에 직접 포함하지 않는다.

## 현재 상태
실서비스 배포 직전 단계가 아니라, 실제 상용 개발을 이어갈 수 있도록 계층/계약/보안 경계를 만든 V2 코드베이스다.
공공 API의 실제 필드와 상업적 이용조건은 공식 명세 확인 후 adapter에 연결한다.
