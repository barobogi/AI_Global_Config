from pydantic import BaseModel, Field

class ParkingLot(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    price_3h: int | None = None
    walking_minutes: int | None = None
    available_spaces: int | None = None
    updated_minutes_ago: int | None = None
    entrance_lat: float | None = None
    entrance_lng: float | None = None

class RecommendationRequest(BaseModel):
    destination: str
    duration_minutes: int = Field(default=180, ge=15, le=1440)
    max_walk_minutes: int = Field(default=15, ge=1, le=60)
    budget: int | None = Field(default=None, ge=0)

class Recommendation(BaseModel):
    parking: ParkingLot
    score: float
    success_probability: float
    confidence: float
    reasons: list[str]
    risks: list[str]
