from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "postgresql+psycopg://parking:parking@localhost:5432/parking"
    redis_url: str = "redis://localhost:6379/0"
    public_parking_api_key: str = ""
    map_api_key: str = ""
    jwt_secret: str = "change-me"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
