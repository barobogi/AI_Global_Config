from fastapi import APIRouter
from app.models.parking import ParkingLot, RecommendationRequest
from app.services.recommendation import recommend

router = APIRouter(prefix="/api/v1/parking", tags=["parking"])

DEMO = [
    ParkingLot(id="P001", name="A 주차장", lat=37.497, lng=127.027, price_3h=6000,
               walking_minutes=5, available_spaces=38, updated_minutes_ago=2,
               entrance_lat=37.4972, entrance_lng=127.0271),
    ParkingLot(id="P002", name="B 주차장", lat=37.498, lng=127.028, price_3h=4000,
               walking_minutes=9, available_spaces=21, updated_minutes_ago=5,
               entrance_lat=37.4982, entrance_lng=127.0282),
    ParkingLot(id="P003", name="C 주차장", lat=37.496, lng=127.026, price_3h=3000,
               walking_minutes=4, available_spaces=3, updated_minutes_ago=42,
               entrance_lat=37.4961, entrance_lng=127.0258),
]

@router.post("/recommendations")
def recommendations(req: RecommendationRequest):
    return recommend(DEMO, req.budget, req.max_walk_minutes)

@router.get("/recommendations")
def recommendations_demo():
    return recommend(DEMO, None, 15)
