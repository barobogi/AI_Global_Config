from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])

class Feedback(BaseModel):
    parking_id: str
    success: bool
    reason: str | None = Field(default=None, max_length=100)

@router.post("/parking")
def parking_feedback(body: Feedback):
    # Production: persist event, rate-limit, anonymize, and feed Data Quality Engine.
    return {"accepted": True, "parking_id": body.parking_id}
