from app.models.parking import ParkingLot, Recommendation

def confidence(p: ParkingLot) -> float:
    freshness = max(0.0, 1.0 - ((p.updated_minutes_ago or 60) / 60))
    return round(0.55 + 0.45 * freshness, 3)

def success_probability(p: ParkingLot) -> float:
    if p.available_spaces is None:
        base = 0.70
    else:
        base = min(0.98, 0.55 + p.available_spaces / 100)
    if (p.updated_minutes_ago or 60) > 30:
        base -= 0.12
    return round(max(0.05, min(0.99, base)), 3)

def recommend(items: list[ParkingLot], budget: int | None, max_walk: int):
    out = []
    for p in items:
        if p.walking_minutes is not None and p.walking_minutes > max_walk:
            continue
        sp = success_probability(p)
        cf = confidence(p)
        price_score = 1.0 if not budget or not p.price_3h else max(0, 1 - p.price_3h / max(budget, 1))
        walk_score = 1.0 if not p.walking_minutes else max(0, 1 - p.walking_minutes / max_walk)
        score = 0.50*sp + 0.30*cf + 0.15*price_score + 0.05*walk_score
        reasons = [
            f"주차 성공 가능성 {round(sp*100)}%",
            f"데이터 신뢰도 {round(cf*100)}%",
        ]
        if p.price_3h is not None:
            reasons.append(f"3시간 예상요금 {p.price_3h:,}원")
        risks = []
        if (p.updated_minutes_ago or 60) > 30:
            risks.append("실시간 데이터가 오래되었습니다.")
        if p.available_spaces is not None and p.available_spaces <= 3:
            risks.append("잔여 주차면이 적습니다.")
        out.append(Recommendation(parking=p, score=round(score, 4),
                                   success_probability=sp, confidence=cf,
                                   reasons=reasons, risks=risks))
    return sorted(out, key=lambda x: x.score, reverse=True)
