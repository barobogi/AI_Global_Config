from fastapi import FastAPI
from app.api.parking import router as parking_router
from app.api.feedback import router as feedback_router

app = FastAPI(title="Parking Where API", version="2.0.0")
app.include_router(parking_router)
app.include_router(feedback_router)

@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0"}
