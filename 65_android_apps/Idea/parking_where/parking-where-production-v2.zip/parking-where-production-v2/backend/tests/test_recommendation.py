from app.models.parking import ParkingLot
from app.services.recommendation import recommend

def test_recommendation_prefers_fresh_available_lot():
    items = [
        ParkingLot(id="a", name="A", lat=0, lng=0, price_3h=6000, walking_minutes=5,
                   available_spaces=30, updated_minutes_ago=2),
        ParkingLot(id="b", name="B", lat=0, lng=0, price_3h=3000, walking_minutes=5,
                   available_spaces=1, updated_minutes_ago=60),
    ]
    result = recommend(items, None, 15)
    assert result[0].parking.id == "a"
    assert result[0].success_probability > result[1].success_probability
