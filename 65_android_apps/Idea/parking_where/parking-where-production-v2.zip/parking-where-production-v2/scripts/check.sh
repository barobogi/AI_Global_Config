#!/usr/bin/env bash
set -e
python -m compileall backend/app
cd backend && pytest -q
