# 외부 검증 메모

- Android 공식 Compose Architecture: https://developer.android.com/develop/ui/compose/architecture
- Android 공식 Compose layering: https://developer.android.com/develop/ui/compose/layering
- FastAPI 공식 Docker 배포: https://fastapi.tiangolo.com/deployment/docker/
- 공공데이터포털: https://www.data.go.kr/

주의: 공공 API의 실제 필드, 인증 방식, 상업적 이용/캐싱/재배포 조건은 구현 시 공식 최신 명세를 확인해야 한다.
