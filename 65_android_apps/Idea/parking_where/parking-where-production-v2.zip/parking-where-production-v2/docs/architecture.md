# Architecture

```text
Public APIs / Partner APIs / User Reports
                |
          Ingestion Worker
                |
        Validation & Normalize
                |
       PostgreSQL + Redis
                |
     Data Quality / Prediction
                |
       Recommendation Engine
                |
          FastAPI REST
                |
     Android Jetpack Compose
```

Android는 UDF + ViewModel + Repository 경계를 유지한다.
Backend는 원천 데이터와 추천 계산을 분리한다.
외부 API adapter를 별도 계층으로 두어 공급자 변경을 쉽게 한다.
