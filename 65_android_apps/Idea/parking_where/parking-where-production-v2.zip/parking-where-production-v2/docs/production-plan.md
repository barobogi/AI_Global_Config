# 주차 어디가? 상용화 확장 기획안 V2

## 1. 제품 정의
공공데이터와 현장 데이터를 결합하여 사용자의 목적/시간/예산/도보 허용거리와 주차 성공 가능성까지 고려해 가장 실패 가능성이 낮은 주차장을 추천한다.

## 2. 핵심 차별화
- Parking Success Probability
- Data Confidence Score
- 현장 불일치 신고
- 차량 입구 안내
- Plan B
- 출발 직전 재검증
- 구매 전 Preflight Check
- 주차 타이머/출차 알림
- 실제 결제금액 기반 품질 개선

## 3. 상용화 단계
P0: 공공데이터, 검색, 추천, 가격, 거리, 운영, Fact Check
P1: 성공확률, 신뢰도, 현장 신고, Plan B, 입구
P2: 자연어, 접근성, EV, 실제 결제 피드백, 예측
P3: 예약/결제/제휴/B2B

## 4. 보안
- 공공 API key는 Android에 포함하지 않는다.
- Secret Manager/환경변수 사용.
- 위치/차량번호/토큰 최소수집.
- 로그에 API key, token, 원본 차량번호, 정밀 위치를 남기지 않는다.
- AI에는 원본 개인정보 대신 구조화된 preference를 전달한다.
- 가격/운영/주차 가능 여부는 LLM이 생성하지 않고 원천 데이터와 계산엔진을 사용한다.

## 5. KPI
- 추천 성공률
- Parking Success Rate
- Prediction Calibration
- Data Freshness
- Incident Resolution Time
- 추천 후 길찾기 전환율
- 주차 실패율

## 6. 출시 전 필수 검증
- 공공 API 이용조건
- 실제 응답 필드/업데이트 주기
- 상업적 이용/캐싱/재배포 조건
- 지도 API 라이선스
- 위치정보/개인정보 법무
- 결제/주차권 제휴 조건
- 장애/오프라인 fallback
