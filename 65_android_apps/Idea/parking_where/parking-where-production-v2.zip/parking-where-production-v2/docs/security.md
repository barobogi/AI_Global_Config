# Security Checklist

- [ ] Secret Manager 적용
- [ ] Android APK에 secret 없음
- [ ] HTTPS only
- [ ] API rate limit
- [ ] authentication/authorization
- [ ] location consent/minimization
- [ ] vehicle number encryption/masking
- [ ] structured logging
- [ ] secret/token redaction
- [ ] dependency scanning
- [ ] SAST/DAST
- [ ] database backup/restore test
- [ ] incident response
- [ ] privacy policy/terms
- [ ] location information compliance review
