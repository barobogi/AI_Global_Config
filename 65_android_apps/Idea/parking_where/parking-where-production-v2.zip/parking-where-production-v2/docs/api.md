# API Contract

## GET /health
서비스 상태.

## GET /api/v1/parking/recommendations
데모 추천 목록.

## POST /api/v1/parking/recommendations
```json
{
  "destination": "강남역",
  "duration_minutes": 180,
  "max_walk_minutes": 15,
  "budget": 8000
}
```

## POST /api/v1/feedback/parking
```json
{
  "parking_id": "P001",
  "success": false,
  "reason": "FULL"
}
```

실제 공공데이터 필드와 연결할 때 adapter/normalizer를 추가한다.
